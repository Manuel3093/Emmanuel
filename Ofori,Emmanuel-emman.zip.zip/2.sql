SELECT CustomerName, SUM(Quantity) AS TotalQuantity
FROM orders 
JOIN Customers ON orders.CustomerID = customers.CustomerID
GROUP BY CustomerName
ORDER BY TotalQuantity DESC;