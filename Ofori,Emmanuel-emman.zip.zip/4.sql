SELECT c.CustomerName, COUNT(o.OrderID) AS OrderCount
FROM Orders o
JOIN Customers c ON o.CustomerID = c.CustomerID
JOIN (
    SELECT OrderID, SUM(Quantity * Price) AS OrderTotal
    FROM orders o 
    JOIN Products p ON o.ProductID = p.ProductID
    GROUP BY OrderID
    HAVING SUM(Quantity * Price) > 100
) filtered_orders ON o.OrderID = filtered_orders.OrderID
WHERE o.OrderDate BETWEEN '2023-12-01' AND '2023-12-31'
GROUP BY c.CustomerName
HAVING COUNT(o.OrderID) >= 2
ORDER BY OrderCount DESC;