SELECT LOWER(ProductName) AS ProductNameLower, SUM(Quantity) AS TotalQuantityOrdered
FROM orders 
JOIN Products ON orders.ProductID = products.ProductID
GROUP BY ProductNameLower;