SELECT OrderID,orders.ProductID,Quantity, Total
FROM orders 
JOIN products ON orders.ProductID = products.ProductID
WHERE Price > 25;