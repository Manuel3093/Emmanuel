SELECT OrderID, LEFT(CustomerName, 3) AS ShortCustomerName, ProductName, Total
FROM Orders 
JOIN Customers ON orders.CustomerID = customers.CustomerID
JOIN Products  ON orders.ProductID = products.ProductID
GROUP BY OrderID;
