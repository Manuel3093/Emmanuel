SELECT ProductName, SUM(Total) AS TotalSales,
CASE
 WHEN SUM(Total) > 300 THEN 'High Revenue'
ELSE 'Low Revenue'
 END AS RevenueCategory
FROM Orders 
JOIN Products ON orders.ProductID = products.ProductID
GROUP BY ProductName;